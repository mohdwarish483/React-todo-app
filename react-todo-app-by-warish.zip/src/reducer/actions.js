export const ACTIONS = {
    ADD_TODO: 'add_todo',
    DELETE_TODO: 'delete_todo',
    COMPLETE_TODO: 'complete_todo',
    EDIT_TODO: 'edit_todo',
    SET_STATE: 'set_state',
}